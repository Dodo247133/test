Static landing site for Azure App Service.
Deploy via Zip Deploy or Local Git.
