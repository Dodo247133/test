PHP demo portal for Azure App Service (Linux, PHP 8.x). No database; demo only.
